  
  
  
  function menuCall(c) {
     let menuDisplay = document.querySelector('.menu');
     
     if (c == 0) {
       menuDisplay.style.display = "block"
     } else if (c == 1){
       menuDisplay.style.display = "none"
     }
 }